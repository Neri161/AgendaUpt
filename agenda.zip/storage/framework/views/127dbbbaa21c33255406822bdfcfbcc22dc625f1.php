<?php $__env->startSection('titulo'); ?>
    <title>Inicio</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <h1 class="text-center"> Bienvenido <?php echo e(session('usuario')->nombre); ?> </h1>
    <center><img src="https://c.tenor.com/xEd-AhmKlZcAAAAS/hi-hello.gif" width="500px" class="img-fluid" alt=""></center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('usuario.layout.usuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\agenda\resources\views/usuario/inicio.blade.php ENDPATH**/ ?>