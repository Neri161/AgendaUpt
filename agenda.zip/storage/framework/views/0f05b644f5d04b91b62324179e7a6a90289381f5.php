<?php $__env->startSection('titulo'); ?>
    <title>Inicio</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('CSS'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/dtjs/bootstrap/css/bootstrap.min.css">
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="/dtjs/datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->
    <link rel="stylesheet" type="text/css" href="/dtjs/datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido Paterno</th>
                        <th>Apellido Materno</th>
                        <th>Direccion</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($contactos->nombre); ?></td>
                            <td><?php echo e($contactos->paterno); ?></td>
                            <td><?php echo e($contactos->materno); ?></td>
                            <td><?php echo e($contactos->Direccion); ?></td>
                            <td><?php echo e($contactos->Correo); ?></td>
                            <td><?php echo e($contactos->Telefono); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- datatables JS -->
    <script type="text/javascript" src="/dtjs/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="/dtjs/main.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('usuario.layout.usuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\agenda\resources\views/usuario/listaContacto.blade.php ENDPATH**/ ?>